// ╔══════════════════════════════════════════════════════════════════╗
// ║  OmniDecoder — Abstracted Configuration                         ║
// ║  API keys and model settings live here only.                    ║
// ║  This file is NEVER referenced in UI code directly.             ║
// ╚══════════════════════════════════════════════════════════════════╝

// window.OmniConfig makes this accessible across all script tags
window.OmniConfig = {
  // ── Gemini API ─────────────────────────────────────────────────────
  // Replace the value below with your Gemini API key.
  // Valid keys start with "AIzaSy" and are 39 characters long.
  // Get one free at: https://aistudio.google.com/app/apikey
  GEMINI_API_KEY: 'AQ.Ab8RN6Lj1-dZy04Y_KDE2creCHMjSaW4C3oN-J_Oai4Nfggz6w',

  // ── Model ──────────────────────────────────────────────────────────
  // gemini-1.5-flash: reliable free tier (1500 req/day, 15 RPM)
  // gemini-2.0-flash: newer but requires billing-enabled project
  GEMINI_MODEL: 'gemini-1.5-flash',
  GEMINI_MODEL_FALLBACK: 'gemini-1.5-flash-latest',

  // ── Endpoint ───────────────────────────────────────────────────────
  GEMINI_ENDPOINT: 'https://generativelanguage.googleapis.com/v1beta/models',

  // ── Limits ─────────────────────────────────────────────────────────
  MAX_PAYLOAD_CHARS: 32000,
  MAX_OUTPUT_TOKENS: 4096,
  TEMPERATURE: 0.1,
};


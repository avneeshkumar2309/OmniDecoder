// ===== OmniDecoder - Core Logic Engine =====
// Zero-Width Inspector, Base64 Padding Analyzer, Custom Alphabet Tuner,
// Shannon Entropy Inspector, Recursive Deep Decoder

'use strict';

// ─── 1. ZERO-WIDTH CHARACTER INSPECTOR ────────────────────────────────────────

const ZW_MAP = {
  '\u200B': { name: 'ZWSP',  hex: 'U+200B', bit: '0' },
  '\u200C': { name: 'ZWNJ',  hex: 'U+200C', bit: '1' },
  '\u200D': { name: 'ZWJ',   hex: 'U+200D', bit: null },
  '\uFEFF': { name: 'BOM',   hex: 'U+FEFF', bit: null },
  '\u200E': { name: 'LRM',   hex: 'U+200E', bit: null },
  '\u200F': { name: 'RLM',   hex: 'U+200F', bit: null },
  '\u2060': { name: 'WJ',    hex: 'U+2060', bit: null },
  '\u2061': { name: 'FA',    hex: 'U+2061', bit: null },
  '\u2062': { name: 'IT',    hex: 'U+2062', bit: null },
  '\u2063': { name: 'IS',    hex: 'U+2063', bit: null },
  '\u2064': { name: 'ITSA',  hex: 'U+2064', bit: null },
  '\u00AD': { name: 'SHY',   hex: 'U+00AD', bit: null },
};

function inspectZeroWidth(text) {
  const found = [];
  const cleaned = [];
  const annotated = [];
  let bitStream = '';
  let hasBits = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const info = ZW_MAP[ch];
    if (info) {
      found.push({ index: i, char: ch, ...info });
      annotated.push(`[${info.name}]`);
      if (info.bit !== null) {
        bitStream += info.bit;
        hasBits = true;
      }
    } else {
      cleaned.push(ch);
      annotated.push(ch);
    }
  }

  let hiddenText = '';
  if (hasBits && bitStream.length >= 8) {
    const padded = bitStream.padEnd(Math.ceil(bitStream.length / 8) * 8, '0');
    for (let i = 0; i < padded.length; i += 8) {
      const byte = padded.slice(i, i + 8);
      const code = parseInt(byte, 2);
      if (code > 0) hiddenText += String.fromCharCode(code);
    }
  }

  return {
    found,
    cleanedText: cleaned.join(''),
    annotatedText: annotated.join(''),
    bitStream,
    hiddenText,
    totalHidden: found.length,
  };
}

// ─── 2. BASE64 PADDING BIT ANALYZER ──────────────────────────────────────────

const B64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const B64_URL   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';

function analyzeBase64Padding(b64Input) {
  const clean = b64Input.replace(/\s/g, '');
  const isUrl = /[-_]/.test(clean) && !/[+/]/.test(clean);
  const alphabet = isUrl ? B64_URL : B64_CHARS;

  // Validate
  const validRe = isUrl ? /^[A-Za-z0-9\-_=]+$/ : /^[A-Za-z0-9+/=]+$/;
  if (!validRe.test(clean)) {
    return { error: 'Input contains characters not in standard Base64 alphabet.' };
  }

  const padCount = (clean.match(/=/g) || []).length;
  const payload = clean.replace(/=/g, '');

  // Decode normally
  let decoded = '';
  let decodeError = null;
  try {
    const bin = isUrl ? clean.replace(/-/g, '+').replace(/_/g, '/') : clean;
    decoded = atob(bin.replace(/=/g, '') + '='.repeat(padCount));
  } catch (e) {
    decodeError = e.message;
  }

  // Extract covert bits from padding
  let covertBits = '';
  let covertText = '';
  const analysisSteps = [];

  if (padCount === 1) {
    // Last group has 3 b64 chars → 18 bits, only 16 needed → 2 covert bits
    const lastIdx = payload.length - 1;
    const lastVal = alphabet.indexOf(payload[lastIdx]);
    if (lastVal !== -1) {
      const covert = lastVal & 0x03; // bottom 2 bits
      covertBits = covert.toString(2).padStart(2, '0');
      analysisSteps.push({
        label: 'Last B64 char',
        char: payload[lastIdx],
        value: lastVal,
        binaryFull: lastVal.toString(2).padStart(6, '0'),
        usedBits: lastVal.toString(2).padStart(6, '0').slice(0, 4),
        covertBits: covertBits,
        covertValue: covert,
      });
    }
  } else if (padCount === 2) {
    // Last group has 2 b64 chars → 12 bits, only 8 needed → 4 covert bits
    const lastIdx = payload.length - 1;
    const lastVal = alphabet.indexOf(payload[lastIdx]);
    if (lastVal !== -1) {
      const covert = lastVal & 0x0F; // bottom 4 bits
      covertBits = covert.toString(2).padStart(4, '0');
      analysisSteps.push({
        label: 'Last B64 char',
        char: payload[lastIdx],
        value: lastVal,
        binaryFull: lastVal.toString(2).padStart(6, '0'),
        usedBits: lastVal.toString(2).padStart(6, '0').slice(0, 2),
        covertBits: covertBits,
        covertValue: covert,
      });
    }
  }

  // BUG-06 fix: only decode covert bits as text when the result is printable ASCII.
  // Without this, 2-bit padding (values 0–3) produces control chars and false positives.
  if (covertBits && covertBits !== '0'.repeat(covertBits.length)) {
    const padded = covertBits.padEnd(Math.ceil(covertBits.length / 8) * 8, '0');
    if (padded.length >= 8) {
      const charCode = parseInt(padded.slice(0, 8), 2);
      if (charCode >= 0x20 && charCode <= 0x7E) {
        covertText = String.fromCharCode(charCode);
      }
    }
  }

  // Statistical anomaly: check all chars for off-alphabet-range values
  const charFreq = {};
  for (const ch of payload) {
    const val = alphabet.indexOf(ch);
    if (val !== -1) charFreq[ch] = (charFreq[ch] || 0) + 1;
  }

  return {
    isUrlSafe: isUrl,
    padCount,
    payloadLength: payload.length,
    decoded,
    decodeError,
    covertBits,
    covertText,
    analysisSteps,
    charFreq,
    // BUG-06 fix: hasCovertData requires non-zero bits AND printable decoded text
    hasCovertData: covertBits !== '' && covertBits !== '0'.repeat(covertBits.length) && covertText.length > 0,
  };
}

// ─── 3. CUSTOM ALPHABET & BASE-X AUTO-TUNER ───────────────────────────────────

const KNOWN_ALPHABETS = {
  'Base64 Standard': 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',
  'Base64 URL-Safe': 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_',
  'Base62':          'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
  'Base58 (Bitcoin)':'123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz',
  'Base36':          '0123456789abcdefghijklmnopqrstuvwxyz',
  'Base32 Standard': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567',
  'Base32 Hex':      '0123456789ABCDEFGHIJKLMNOPQRSTUV',
  'Base85 (ASCII)':  '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~',
  'Hex (lowercase)': '0123456789abcdef',
  'Hex (uppercase)': '0123456789ABCDEF',
};

function decodeBase58(str, alphabet) {
  if (!str) return null; // BUG-12 fix: guard against empty input
  const base = BigInt(alphabet.length);
  let num = BigInt(0);
  for (const ch of str) {
    const idx = alphabet.indexOf(ch);
    if (idx === -1) return null;
    num = num * base + BigInt(idx);
  }
  const bytes = [];
  while (num > 0n) {
    bytes.unshift(Number(num % 256n));
    num = num / 256n;
  }
  // Leading zeros from leading alphabet[0] chars
  for (const ch of str) {
    if (ch === alphabet[0]) bytes.unshift(0);
    else break;
  }
  return bytes;
}

function decodeBase32(str, alphabet) {
  str = str.replace(/=/g, '').toUpperCase();
  const alphaUpper = alphabet.toUpperCase(); // BUG-03 fix: pre-compute outside loop
  let bits = '';
  for (const ch of str) {
    const idx = alphaUpper.indexOf(ch);
    if (idx === -1) return null;
    bits += idx.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return bytes;
}

function analyzeCustomAlphabet(input) {
  const chars = new Set(input.replace(/\s/g, ''));
  const charArray = [...chars].sort();
  const uniqueCount = chars.size;
  const inputClean = input.replace(/\s/g, '');

  // Character frequency
  const freq = {};
  for (const ch of inputClean) {
    freq[ch] = (freq[ch] || 0) + 1;
  }
  const sortedFreq = Object.entries(freq).sort((a, b) => b[1] - a[1]);

  // Match against known alphabets
  const matches = [];
  for (const [name, alpha] of Object.entries(KNOWN_ALPHABETS)) {
    const alphaSet = new Set(alpha);
    const inputSet = new Set(inputClean);
    const intersection = [...inputSet].filter(c => alphaSet.has(c));
    const coverage = intersection.length / inputSet.size;
    const contained = [...inputSet].every(c => alphaSet.has(c));
    if (contained || coverage > 0.8) {
      matches.push({ name, alphabet: alpha, base: alpha.length, coverage: Math.round(coverage * 100), contained });
    }
  }
  matches.sort((a, b) => b.coverage - a.coverage);

  // Attempt decodes
  const decodeResults = [];
  for (const match of matches.slice(0, 3)) {
    let result = null;
    let decoded = null;
    try {
      if (match.name.startsWith('Base64')) {
        const bin = inputClean.replace(/-/g, '+').replace(/_/g, '/');
        const padded = bin + '='.repeat((4 - bin.length % 4) % 4);
        decoded = atob(padded);
        result = { format: match.name, text: decoded, bytes: null };
      } else if (match.name.startsWith('Base58')) {
        const bytes = decodeBase58(inputClean, match.alphabet);
        if (bytes) {
          decoded = String.fromCharCode(...bytes); // BUG-02 fix: null bytes (0x00) are valid — don't filter them
          result = { format: match.name, text: decoded, bytes };
        }
      } else if (match.name.startsWith('Base32')) {
        const bytes = decodeBase32(inputClean, match.alphabet);
        if (bytes) {
          decoded = String.fromCharCode(...bytes);
          result = { format: match.name, text: decoded, bytes };
        }
      } else if (match.name.startsWith('Hex')) {
        decoded = inputClean.match(/.{1,2}/g)?.map(h => String.fromCharCode(parseInt(h, 16))).join('') ?? null;
        if (decoded) result = { format: match.name, text: decoded, bytes: null };
      }
    } catch (e) { /* ignore */ }
    if (result) decodeResults.push(result);
  }

  return {
    uniqueCount,
    charArray,
    sortedFreq,
    matches,
    decodeResults,
    inputLength: inputClean.length,
  };
}

// ─── 4. SHANNON ENTROPY & FORENSIC BINARY INSPECTOR ──────────────────────────

const MAGIC_SIGNATURES = [
  { name: 'ZIP Archive',   bytes: [0x50, 0x4B, 0x03, 0x04], offset: 0 },
  { name: 'ZIP Archive',   bytes: [0x50, 0x4B, 0x05, 0x06], offset: 0 },
  { name: 'Gzip',          bytes: [0x1F, 0x8B],              offset: 0 },
  { name: 'PNG Image',     bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], offset: 0 },
  { name: 'JPEG Image',    bytes: [0xFF, 0xD8, 0xFF],        offset: 0 },
  { name: 'GIF Image',     bytes: [0x47, 0x49, 0x46, 0x38], offset: 0 },
  { name: 'BMP Image',     bytes: [0x42, 0x4D],              offset: 0 },
  { name: 'PDF Document',  bytes: [0x25, 0x50, 0x44, 0x46], offset: 0 },
  { name: 'ELF Binary',    bytes: [0x7F, 0x45, 0x4C, 0x46], offset: 0 },
  { name: 'PE Windows Exe',bytes: [0x4D, 0x5A],              offset: 0 },
  { name: 'RAR Archive',   bytes: [0x52, 0x61, 0x72, 0x21, 0x1A, 0x07], offset: 0 },
  { name: '7z Archive',    bytes: [0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C], offset: 0 },
  { name: 'SQLite DB',     bytes: [0x53, 0x51, 0x4C, 0x69, 0x74, 0x65], offset: 0 },
  { name: 'Class File (Java)', bytes: [0xCA, 0xFE, 0xBA, 0xBE], offset: 0 },
  { name: 'WebP Image',    bytes: [0x57, 0x45, 0x42, 0x50], offset: 8 },
];

function calcEntropy(bytes) {
  if (!bytes || bytes.length === 0) return 0;
  const freq = new Array(256).fill(0);
  for (const b of bytes) freq[b]++;
  let entropy = 0;
  const n = bytes.length;
  for (const count of freq) {
    if (count > 0) {
      const p = count / n;
      entropy -= p * Math.log2(p);
    }
  }
  return entropy;
}

function buildByteHistogram(bytes) {
  const hist = new Array(256).fill(0);
  for (const b of bytes) hist[b]++;
  return hist;
}

function detectMagic(bytes) {
  const hits = [];
  for (const sig of MAGIC_SIGNATURES) {
    const offset = sig.offset;
    if (bytes.length < offset + sig.bytes.length) continue;
    let match = true;
    for (let i = 0; i < sig.bytes.length; i++) {
      if (bytes[offset + i] !== sig.bytes[i]) { match = false; break; }
    }
    if (match) hits.push(sig.name);
  }
  return hits;
}

function textToBytes(text) {
  const encoder = new TextEncoder();
  return Array.from(encoder.encode(text));
}

function hexToBytes(hexStr) {
  const clean = hexStr.replace(/\s/g, '');
  if (!/^[0-9a-fA-F]+$/.test(clean) || clean.length % 2 !== 0) return null;
  const bytes = [];
  for (let i = 0; i < clean.length; i += 2) {
    bytes.push(parseInt(clean.slice(i, i + 2), 16));
  }
  return bytes;
}

function base64ToBytes(b64) {
  try {
    const bin = atob(b64.replace(/-/g, '+').replace(/_/g, '/'));
    return Array.from(bin).map(c => c.charCodeAt(0));
  } catch { return null; }
}

function inspectEntropy(input, inputType = 'auto') {
  let bytes = null;
  let detectedType = inputType;

  if (inputType === 'auto') {
    const trimmed = input.trim();
    // BUG-10 fix: detect odd-length hex before it silently falls through to text mode
    const hexStripped = trimmed.replace(/\s/g, '');
    const looksLikeHex = /^[0-9a-fA-F\s]+$/.test(trimmed) && hexStripped.length > 1;
    if (looksLikeHex && hexStripped.length % 2 !== 0) {
      return { error: `Input looks like hex but has odd length (${hexStripped.length} chars). Pad the first byte with a leading zero (e.g. '0a' not 'a').` };
    }
    const hexBytes = hexToBytes(trimmed);
    if (hexBytes) { bytes = hexBytes; detectedType = 'hex'; }
    else {
      const b64Bytes = base64ToBytes(trimmed);
      if (b64Bytes) { bytes = b64Bytes; detectedType = 'base64'; }
      else { bytes = textToBytes(input); detectedType = 'text'; }
    }
  } else if (inputType === 'hex') {
    bytes = hexToBytes(input.trim());
    if (!bytes) return { error: 'Invalid hex string.' };
  } else if (inputType === 'base64') {
    bytes = base64ToBytes(input.trim());
    if (!bytes) return { error: 'Invalid Base64 string.' };
  } else {
    bytes = textToBytes(input);
  }

  const entropy = calcEntropy(bytes);
  const histogram = buildByteHistogram(bytes);
  const magicHits = detectMagic(bytes);

  // Classify entropy
  let classification = '';
  let classColor = '';
  if (entropy < 1) { classification = 'Very Low — likely uniform/repetitive'; classColor = '#4ade80'; }
  else if (entropy < 3) { classification = 'Low — structured plain text or simple encoding'; classColor = '#a3e635'; }
  else if (entropy < 5) { classification = 'Medium — compressed or mixed content'; classColor = '#facc15'; }
  else if (entropy < 7) { classification = 'High — encrypted, compressed, or Base64 data'; classColor = '#fb923c'; }
  else { classification = 'Very High — likely AES ciphertext or random noise'; classColor = '#f87171'; }

  // Top 10 most frequent bytes
  const topBytes = histogram
    .map((count, byte) => ({ byte, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  // Printable ASCII stats
  const printable = bytes.filter(b => b >= 0x20 && b <= 0x7E).length;
  const printableRatio = bytes.length > 0 ? printable / bytes.length : 0;

  return {
    byteCount: bytes.length,
    detectedType,
    entropy: entropy.toFixed(4),
    entropyNum: entropy,
    classification,
    classColor,
    histogram,
    topBytes,
    magicHits,
    printableRatio: (printableRatio * 100).toFixed(1),
    bytes: bytes.slice(0, 256), // first 256 for hex preview
  };
}

// ─── 5. RECURSIVE DEEP DECODING PIPELINE ─────────────────────────────────────

const DECODERS = {
  'Zero-Width Strip': (s) => {
    const result = inspectZeroWidth(s);
    if (result.totalHidden > 0) {
      return { output: result.cleanedText, note: `Stripped ${result.totalHidden} zero-width chars. Hidden bits: ${result.bitStream}` };
    }
    return null;
  },
  'Base64': (s) => {
    try {
      // BUG-11 fix: replace URL-safe chars BEFORE adding padding.
      // atob() cannot handle '-' or '_'; padding must be applied to the already-standard string.
      const clean = s.trim().replace(/\s/g, '').replace(/-/g, '+').replace(/_/g, '/');
      const padded = clean + '='.repeat((4 - clean.length % 4) % 4);
      const decoded = atob(padded);
      if (decoded && decoded !== s && decoded.length > 0) return { output: decoded, note: 'Decoded Base64' };
    } catch { }
    return null;
  },
  'Hex': (s) => {
    const clean = s.trim().replace(/\s/g, '');
    if (!/^[0-9a-fA-F]+$/.test(clean) || clean.length % 2 !== 0 || clean.length < 4) return null;
    const decoded = clean.match(/.{1,2}/g).map(h => String.fromCharCode(parseInt(h, 16))).join('');
    if (decoded && decoded !== s) return { output: decoded, note: 'Decoded Hex' };
    return null;
  },
  'URL Decode': (s) => {
    try {
      const decoded = decodeURIComponent(s);
      if (decoded !== s) return { output: decoded, note: 'URL decoded' };
    } catch { }
    return null;
  },
  'ROT13': (s) => {
    // BUG-07 fix: ROT13 fires on EVERY string with letters (always produces a different output).
    // Guard with an English frequency score — only apply if the rotated output is more likely English.
    if (!/[a-zA-Z]/.test(s)) return null;
    const decoded = s.replace(/[a-zA-Z]/g, c => {
      const base = c <= 'Z' ? 65 : 97;
      return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
    });
    const scoreOrig = scoreEnglish(s);
    const scoreRot  = scoreEnglish(decoded);
    // Only fire if rotated result is at least 20% more English-like than the original
    if (scoreRot > scoreOrig * 1.2 && decoded !== s) return { output: decoded, note: 'ROT13 applied' };
    return null;
  },
  'Base32': (s) => {
    const bytes = decodeBase32(s.trim(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567');
    if (bytes) {
      const decoded = String.fromCharCode(...bytes);
      if (decoded && decoded !== s) return { output: decoded, note: 'Decoded Base32' };
    }
    return null;
  },
  'XOR-0xFF': (s) => {
    const bytes = textToBytes(s);
    const xored = bytes.map(b => b ^ 0xFF);
    const decoded = String.fromCharCode(...xored);
    const printable = xored.filter(b => b >= 0x20 && b <= 0x7E).length / xored.length;
    if (printable > 0.7 && decoded !== s) return { output: decoded, note: 'XOR with 0xFF' };
    return null;
  },
};

function runPipeline(input, options = {}) {
  const maxDepth = options.maxDepth || 8;
  const steps = [];
  let current = input;
  const visited = new Set([input]);

  for (let depth = 0; depth < maxDepth; depth++) {
    let progressed = false;
    for (const [name, fn] of Object.entries(DECODERS)) {
      if (options.skipDecoders && options.skipDecoders.includes(name)) continue;
      const result = fn(current);
      if (result && !visited.has(result.output)) {
        steps.push({
          step: steps.length + 1,
          decoder: name,
          input: current,
          output: result.output,
          note: result.note,
          entropy: parseFloat(inspectEntropy(result.output).entropy ?? '0'), // BUG-04 fix: inspectEntropy can return {error} with no .entropy → NaN.toFixed(2) crash
        });
        visited.add(result.output);
        current = result.output;
        progressed = true;
        break;
      }
    }
    if (!progressed) break;
  }

  return { steps, finalOutput: current, totalSteps: steps.length };
}

// ─── XOR BRUTE FORCE ──────────────────────────────────────────────────────────

function xorBruteForce(input, keyMin = 0, keyMax = 255) {
  const bytes = textToBytes(input);
  const results = [];
  for (let key = keyMin; key <= keyMax; key++) {
    const xored = bytes.map(b => b ^ key);
    const decoded = String.fromCharCode(...xored);
    const printable = xored.filter(b => b >= 0x20 && b <= 0x7E).length / xored.length;
    if (printable > 0.75) {
      results.push({ key: `0x${key.toString(16).padStart(2, '0').toUpperCase()}`, keyDec: key, decoded, printableRatio: (printable * 100).toFixed(1) });
    }
  }
  results.sort((a, b) => parseFloat(b.printableRatio) - parseFloat(a.printableRatio));
  return results.slice(0, 20);
}

// ─── CAESAR BRUTE FORCE ───────────────────────────────────────────────────────

const ENGLISH_FREQS = { e:12.7,t:9.1,a:8.2,o:7.5,i:7.0,n:6.7,s:6.3,h:6.1,r:6.0,d:4.3,l:4.0,c:2.8,u:2.8,m:2.4,w:2.4,f:2.2,g:2.0,y:2.0,p:1.9,b:1.5,v:1.0,k:0.8,x:0.2,j:0.2,q:0.1,z:0.1 };

function scoreEnglish(text) {
  const lower = text.toLowerCase();
  let score = 0;
  for (const ch of lower) {
    if (ENGLISH_FREQS[ch]) score += ENGLISH_FREQS[ch];
  }
  return score / text.length;
}

function caesarBruteForce(input) {
  const results = [];
  for (let shift = 0; shift < 26; shift++) {
    const decoded = input.replace(/[a-zA-Z]/g, c => {
      const base = c <= 'Z' ? 65 : 97;
      return String.fromCharCode(((c.charCodeAt(0) - base + shift) % 26) + base);
    });
    results.push({ shift, decoded, score: scoreEnglish(decoded) });
  }
  results.sort((a, b) => b.score - a.score);
  return results;
}

// ─── 6. INTERLEAVED NOISE PATTERN STRIPPER ────────────────────────────────────
//
// Detects a visible repeating string (e.g. "vVv", "00", "XxX") that has been
// inserted between EVERY real character in a payload. Automatically identifies
// the separator without any user input by testing all candidate separator lengths
// and picking the one that produces the most consistent repeating pattern.
//
// Example: "CvVv:vVv\vVvuvVv..." → separator "vVv" → "C:\u..."

function detectInterleavedNoise(input) {
  // Clamp to a reasonable length for analysis
  const text = input.replace(/\r?\n/g, '');
  const len = text.length;

  if (len < 3) {
    return { error: 'Input too short for interleaved noise detection (need ≥ 3 chars).' };
  }

  // ── Step 1: Score every candidate separator length from 1 up to ~12 chars ──
  // For separator length L, the string structure is:
  //   real[0] + sep(L) + real[1] + sep(L) + real[2] + ...
  // period = L + 1  (one real char + L sep chars)
  // The separator candidate is text.slice(1, 1+L).
  // We validate by checking that the same L-char pattern appears at every
  // position (k*(L+1)+1) for k = 0,1,2,...
  //
  // Score = fraction of expected positions that actually match.

  const MAX_SEP_LEN = Math.min(12, Math.floor((len - 1) / 2));
  const candidates = [];

  for (let L = 1; L <= MAX_SEP_LEN; L++) {
    const period  = L + 1;
    const sepCandidate = text.slice(1, 1 + L);
    if (!sepCandidate || sepCandidate.length < L) continue;

    let matches = 0;
    let total   = 0;

    for (let pos = 1; pos + L <= len; pos += period) {
      total++;
      if (text.slice(pos, pos + L) === sepCandidate) matches++;
    }

    if (total === 0) continue;
    const score = matches / total;

    candidates.push({
      separatorLen : L,
      separator    : sepCandidate,
      period,
      matches,
      total,
      score,
    });
  }

  if (candidates.length === 0) {
    return { error: 'Could not find any repeating interleaved pattern.' };
  }

  // ── Step 2: Pick the best candidate ──
  // Prefer high score, then longer separator (more specific / less likely to be noise).
  candidates.sort((a, b) => {
    if (Math.abs(a.score - b.score) > 0.05) return b.score - a.score;
    return b.separatorLen - a.separatorLen;
  });

  const best = candidates[0];

  // Require a minimum confidence threshold
  if (best.score < 0.75) {
    return {
      error: `No reliable interleaved separator found (best confidence: ${(best.score*100).toFixed(1)}%). The input may not use a consistent noise pattern.`,
      candidates: candidates.slice(0, 5),
    };
  }

  // ── Step 3: Extract the real characters by taking every (L+1)-th char ──
  const { separator, period } = best;
  const realChars = [];
  for (let pos = 0; pos < len; pos += period) {
    realChars.push(text[pos]);
  }
  const cleaned = realChars.join('');

  // ── Step 4: Build annotated view showing where noise was stripped ──
  const segments = [];
  for (let pos = 0; pos < len; pos += period) {
    segments.push({ real: text[pos], noise: text.slice(pos + 1, pos + 1 + best.separatorLen) });
  }

  // ── Step 5: Compute confidence detail for all top candidates ──
  const topCandidates = candidates.slice(0, 8).map(c => ({
    separator    : c.separator,
    separatorLen : c.separatorLen,
    confidence   : Math.round(c.score * 100),
    matches      : c.matches,
    total        : c.total,
  }));

  return {
    separator,
    separatorLen  : best.separatorLen,
    period,
    confidence    : Math.round(best.score * 100),
    matches       : best.matches,
    total         : best.total,
    cleaned,
    originalLength: len,
    cleanedLength : cleaned.length,
    segments,
    topCandidates,
    noisePercent  : Math.round((1 - 1 / period) * 100),
  };
}

// ─── 7. AI AUTO-ANALYZER ENGINE ───────────────────────────────────────────────

// Expected decoded/original length ratios per encoding
const DECODE_RATIOS = {
  'Base64': 0.75, 'Base32': 0.625, 'Hex': 0.5,
  'URL': 0.85, 'Caesar': 1.0, 'ROT13': 1.0,
  'XOR': 1.0, 'Binary': 0.125, 'Noise': 0.25,
};

// Keyword patterns indicating meaningful decoded content
const KEYWORD_PATTERNS = [
  /https?:\/\//i,
  /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i,
  /\b(the|and|for|that|this|with|from|have|will|secret|flag|key)\b/i,
  /^\s*[\{\[]/,
  /<[a-z]+[\s>]/i,
  /CTF\{|flag\{/i,
  /[A-Z]:\\|\/usr\/|\/home\/|\/etc\//,
  /BEGIN (RSA|CERTIFICATE|PRIVATE)/,
  /password|secret|token|api_key/i,
  /SELECT|INSERT|UPDATE|DROP/i,
];

function _countKeywordHits(text) {
  return KEYWORD_PATTERNS.filter(p => p.test(text)).length;
}

function _calcPrintableRatio(text) {
  if (!text.length) return 0;
  let n = 0;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    if (c >= 0x20 && c <= 0x7E) n++;
  }
  return n / text.length;
}

function _calcEntropyNum(text) {
  const freq = {};
  for (const c of text) freq[c] = (freq[c] || 0) + 1;
  const len = text.length;
  let e = 0;
  for (const c in freq) { const p = freq[c] / len; e -= p * Math.log2(p); }
  return e;
}

function _scoreDecodeResult(original, decoded, method) {
  if (!decoded || decoded === original || !decoded.length) return 0;
  const printable = _calcPrintableRatio(decoded) * 35;
  const origH = _calcEntropyNum(original);
  const decH  = _calcEntropyNum(decoded);
  const entropyScore = Math.min(25, Math.max(0, (origH - decH) / Math.max(origH, 0.01)) * 25);
  const keywordScore = Math.min(20, _countKeywordHits(decoded) * 5);
  const expectedRatio = DECODE_RATIOS[method] || 0.75;
  const actualRatio   = decoded.length / original.length;
  const ratioScore    = Math.max(0, 10 - Math.abs(actualRatio - expectedRatio) * 12);
  const diffScore     = decoded !== original ? 10 : 0;
  return Math.round(Math.min(99, Math.max(0, printable + entropyScore + keywordScore + ratioScore + diffScore)));
}

function detectFingerprints(input) {
  const c = input.trim();
  const prints = [];
  if (/^[A-Za-z0-9+/]+=*$/.test(c) && c.length % 4 === 0)
    prints.push({ name: 'Base64 (Standard)', confidence: 90 });
  if (/^[A-Za-z0-9\-_]+=*$/.test(c) && c.length > 4)
    prints.push({ name: 'Base64 (URL-safe)', confidence: 80 });
  if (/^[0-9a-fA-F\s]+$/.test(c) && c.replace(/\s/g,'').length % 2 === 0)
    prints.push({ name: 'Hexadecimal', confidence: 88 });
  if (/%[0-9a-fA-F]{2}/.test(c))
    prints.push({ name: 'URL-encoded', confidence: 95 });
  if (/[\u200B\u200C\u200D\uFEFF\u200E\u200F]/.test(input))
    prints.push({ name: 'Zero-Width Steganography', confidence: 99 });
  if (/^[01\s]+$/.test(c) && c.replace(/\s/g,'').length % 8 === 0)
    prints.push({ name: 'Binary (8-bit ASCII)', confidence: 90 });
  if (/^[A-Z2-7]+=*$/.test(c) && c.length % 8 === 0)
    prints.push({ name: 'Base32', confidence: 82 });
  if (/&[a-z]+;|&#\d+;/.test(c))
    prints.push({ name: 'HTML Entities', confidence: 95 });
  if (/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(c))
    prints.push({ name: 'JWT (JSON Web Token)', confidence: 92 });
  if (/^[1-9A-HJ-NP-Za-km-z]{25,}$/.test(c))
    prints.push({ name: 'Base58', confidence: 72 });
  if (/^[A-Za-z]+$/.test(c) && c.length > 4)
    prints.push({ name: 'Possible Caesar/ROT cipher', confidence: 55 });
  try {
    const n = detectInterleavedNoise(input);
    if (!n.error && n.confidence >= 80)
      prints.push({ name: `Interleaved Noise ("${n.separator}")`, confidence: n.confidence });
  } catch(e) {}
  return prints.sort((a,b) => b.confidence - a.confidence);
}

function autoAnalyze(payload) {
  if (!payload || !payload.trim()) return { error: 'Empty input.' };
  const clean = payload.trim();
  const candidates = [];

  // ── Base64 ──────────────────────────────────────────────────────────────────
  try {
    const r = analyzeBase64Padding(clean);
    if (r.decoded && !r.error) {
      candidates.push({
        method: 'Base64', icon: '🔐',
        confidence: _scoreDecodeResult(clean, r.decoded, 'Base64'),
        decoded: r.decoded,
        explanation: `Length ${clean.length} (mod 4 = ${clean.length%4}), standard Base64 alphabet detected.${r.isUrlSafe?' URL-safe variant.':''}`,
      });
    }
  } catch(e) {}

  // ── Hex ─────────────────────────────────────────────────────────────────────
  try {
    const hexB = hexToBytes(clean.replace(/\s/g,''));
    if (hexB) {
      const decoded = hexB.map(b => String.fromCharCode(b)).join('');
      candidates.push({
        method: 'Hex', icon: '🔢',
        confidence: _scoreDecodeResult(clean, decoded, 'Hex'),
        decoded,
        explanation: `All chars in [0-9a-fA-F], even length → ${hexB.length} bytes decoded.`,
      });
    }
  } catch(e) {}

  // ── URL Decode ──────────────────────────────────────────────────────────────
  try {
    const decoded = decodeURIComponent(clean);
    if (decoded !== clean) {
      candidates.push({
        method: 'URL Decode', icon: '🌐',
        confidence: Math.max(60, _scoreDecodeResult(clean, decoded, 'URL')),
        decoded,
        explanation: 'Contains %XX percent-encoded sequences — successfully URL-decoded.',
      });
    }
  } catch(e) {}

  // ── Zero-Width ───────────────────────────────────────────────────────────────
  try {
    const zw = inspectZeroWidth(payload);
    if (zw.found.length > 0 && zw.decoded) {
      candidates.push({
        method: 'Zero-Width Steganography', icon: '👁️',
        confidence: 97,
        decoded: zw.decoded,
        explanation: `${zw.found.length} hidden zero-width Unicode chars (${[...new Set(zw.found.map(f=>f.name))].join(', ')}) encode a binary bit-stream.`,
      });
    }
  } catch(e) {}

  // ── Interleaved Noise ────────────────────────────────────────────────────────
  try {
    const noise = detectInterleavedNoise(payload);
    if (!noise.error) {
      candidates.push({
        method: `Interleaved Noise ("${noise.separator}")`, icon: '🧹',
        confidence: noise.confidence,
        decoded: noise.cleaned,
        explanation: `"${noise.separator}" (${noise.separatorLen} chars) injected between every real character — ${noise.noisePercent}% of input is noise.`,
      });
    }
  } catch(e) {}

  // ── Caesar / ROT ─────────────────────────────────────────────────────────────
  try {
    const rots = caesarBruteForce(clean);
    const best = rots[0];
    if (best && best.score > 0.04 && best.shift !== 0) {
      const conf = Math.min(88, Math.round(best.score * 350));
      candidates.push({
        method: `Caesar / ROT${best.shift}`, icon: '🔄',
        confidence: conf,
        decoded: best.decoded,
        explanation: `ROT${best.shift} yields highest English frequency score (${best.score.toFixed(4)}).`,
      });
    }
  } catch(e) {}

  // ── XOR Single-Byte ──────────────────────────────────────────────────────────
  try {
    const xors = xorBruteForce(payload);
    if (xors.length > 0) {
      const best = xors[0];
      const conf = Math.min(85, Math.round(parseFloat(best.printableRatio)));
      candidates.push({
        method: `XOR (key ${best.key})`, icon: '⚡',
        confidence: conf,
        decoded: best.decoded,
        explanation: `Single-byte XOR key ${best.key} → ${best.printableRatio}% printable ASCII output.`,
      });
    }
  } catch(e) {}

  // ── Binary (8-bit) ───────────────────────────────────────────────────────────
  try {
    const binStr = clean.replace(/\s/g,'');
    if (/^[01]+$/.test(binStr) && binStr.length % 8 === 0) {
      const decoded = binStr.match(/.{8}/g).map(b => String.fromCharCode(parseInt(b,2))).join('');
      candidates.push({
        method: 'Binary (8-bit ASCII)', icon: '💻',
        confidence: _scoreDecodeResult(clean, decoded, 'Binary'),
        decoded,
        explanation: `Only 0/1 chars, length ${binStr.length} divisible by 8 — each 8-bit group decoded to ASCII char.`,
      });
    }
  } catch(e) {}

  // ── HTML Entities ─────────────────────────────────────────────────────────────
  try {
    const htmlD = clean
      .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
      .replace(/&quot;/g,'"').replace(/&apos;/g,"'")
      .replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(n))
      .replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCharCode(parseInt(h,16)));
    if (htmlD !== clean) {
      candidates.push({
        method: 'HTML Entities', icon: '📄',
        confidence: Math.max(70, _scoreDecodeResult(clean, htmlD, 'URL')),
        decoded: htmlD,
        explanation: 'HTML entity sequences (&amp;, &#xx;, &#xhh;) detected and decoded.',
      });
    }
  } catch(e) {}

  // ── Base32 ───────────────────────────────────────────────────────────────────
  try {
    const b32bytes = decodeBase32(clean.replace(/\s/g,'').toUpperCase(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567');
    if (b32bytes) {
      const decoded = String.fromCharCode(...b32bytes);
      const conf = _scoreDecodeResult(clean, decoded, 'Base32');
      if (conf > 20) {
        candidates.push({
          method: 'Base32', icon: '🔡',
          confidence: conf,
          decoded,
          explanation: 'Characters in [A-Z2-7] with optional padding — decoded as standard Base32 (RFC 4648).',
        });
      }
    }
  } catch(e) {}

  // ── Sort by confidence ────────────────────────────────────────────────────────
  candidates.sort((a,b) => b.confidence - a.confidence);

  // ── Multi-pass recursive unwrapping ─────────────────────────────────────────
  const decodeChain = [];
  let current = payload;
  const visited = new Set([payload]);
  for (let depth = 0; depth < 8; depth++) {
    const step = _autoAnalyzeStep(current);
    if (!step || visited.has(step.decoded) || step.confidence < 35) break;
    decodeChain.push({ step: depth+1, input: current, ...step });
    visited.add(step.decoded);
    current = step.decoded;
  }

  const finalOutput = decodeChain.length > 0
    ? decodeChain[decodeChain.length-1].decoded
    : (candidates[0]?.decoded || payload);

  return {
    candidates: candidates.slice(0,10),
    decodeChain,
    finalOutput,
    fingerprints: detectFingerprints(payload),
    inputLength: payload.length,
    topMethod: candidates[0]?.method || 'Unknown',
    topConfidence: candidates[0]?.confidence || 0,
  };
}

function _autoAnalyzeStep(input) {
  const clean = input.trim();
  const tries = [
    () => {
      const r = analyzeBase64Padding(clean);
      if (r.decoded && !r.error && r.decoded !== input)
        return { method:'Base64', decoded:r.decoded, confidence:_scoreDecodeResult(clean,r.decoded,'Base64'), icon:'🔐' };
    },
    () => {
      const b = hexToBytes(clean.replace(/\s/g,''));
      if (b) { const d = b.map(x=>String.fromCharCode(x)).join(''); if (d !== input) return { method:'Hex', decoded:d, confidence:_scoreDecodeResult(clean,d,'Hex'), icon:'🔢' }; }
    },
    () => {
      try { const d = decodeURIComponent(clean); if (d !== clean) return { method:'URL Decode', decoded:d, confidence:80, icon:'🌐' }; } catch(e){}
    },
    () => {
      const n = detectInterleavedNoise(input);
      if (!n.error && n.confidence >= 80) return { method:`Noise("${n.separator}")`, decoded:n.cleaned, confidence:n.confidence, icon:'🧹' };
    },
    () => {
      const zw = inspectZeroWidth(input);
      if (zw.found.length > 0 && zw.decoded) return { method:'Zero-Width', decoded:zw.decoded, confidence:97, icon:'👁️' };
    },
  ];
  const results = tries.map(t => { try { return t(); } catch(e){ return null; } }).filter(Boolean);
  results.sort((a,b) => b.confidence - a.confidence);
  return results[0] || null;
}

// ── Gemini API Integration ────────────────────────────────────────────────────

const GEMINI_SYSTEM_PROMPT = `You are an expert forensic analyst specializing in data encoding, cryptography, steganography, and CTF challenges. You have deep knowledge of: Base64 (standard and URL-safe), Base32, Base58, Hex, URL-encoding, Binary, ASCII85, all Caesar/ROT variants, XOR ciphers, zero-width Unicode steganography, interleaved character noise, JWT, HTML entities, Unicode escapes, and custom encoding schemes.

Your task: Analyze the payload and:
1. Identify EVERY encoding/obfuscation layer (there may be multiple stacked layers)
2. Decode each layer step-by-step with exact intermediate decoded values
3. Explain precisely WHY you identified each encoding (what specific features gave it away)
4. State confidence percentage for each layer
5. Give the final plaintext output

IMPORTANT: Respond ONLY with valid JSON in this exact schema:
{
  "summary": "One-line description of what was found",
  "layers": [
    {
      "step": 1,
      "method": "Base64",
      "input_preview": "first 80 chars of the input to this step",
      "output": "full decoded output of this step",
      "explanation": "Precise explanation of detection and decoding method",
      "confidence": 97
    }
  ],
  "final_output": "The final decoded plaintext result",
  "overall_confidence": 95,
  "notes": "Any extra observations, alternative interpretations, or warnings"
}`;

async function _callGemini(payload, model) {
  const cfg = window.OmniConfig;
  const url = `${cfg.GEMINI_ENDPOINT}/${model}:generateContent?key=${cfg.GEMINI_API_KEY}`;
  const body = {
    contents: [{ parts: [{ text: `${GEMINI_SYSTEM_PROMPT}\n\nPAYLOAD TO ANALYZE:\n\`\`\`\n${payload}\n\`\`\`` }] }],
    generationConfig: {
      temperature: cfg.TEMPERATURE,
      maxOutputTokens: cfg.MAX_OUTPUT_TOKENS,
      responseMimeType: 'application/json',
    },
  };

  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const errData = await resp.json().catch(() => ({}));
    const msg = errData?.error?.message || `HTTP ${resp.status}`;
    const status = resp.status;

    // Quota exceeded — give specific actionable guidance
    if (status === 429 || msg.toLowerCase().includes('quota')) {
      const retryMatch = msg.match(/retry in ([\d.]+)s/i);
      const retryIn = retryMatch ? `Retry in ${Math.ceil(parseFloat(retryMatch[1]))} seconds.` : '';

      // Check if limit:0 (API not enabled in project)
      const isLimitZero = msg.includes('limit: 0') || msg.includes('limit:0');
      if (isLimitZero) {
        throw Object.assign(new Error('QUOTA_ZERO'), { isQuotaZero: true });
      }
      throw Object.assign(new Error(`QUOTA_EXCEEDED:${retryIn}`), { isQuota: true, retryIn });
    }

    throw new Error(`Gemini API error (${model}): ${msg}`);
  }

  const data = await resp.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini returned an empty response.');

  try {
    return JSON.parse(text);
  } catch(e) {
    const match = text.match(/```(?:json)?\s*([\s\S]+?)\s*```/);
    if (match) return JSON.parse(match[1]);
    throw new Error('Could not parse Gemini response as JSON.');
  }
}

async function analyzeWithGemini(payload) {
  const cfg = window.OmniConfig;

  // ── Key check ──────────────────────────────────────────────
  if (!cfg || !cfg.GEMINI_API_KEY || cfg.GEMINI_API_KEY === 'PASTE_YOUR_GEMINI_API_KEY_HERE') {
    throw new Error('NOKEY');
  }
  if (payload.length > cfg.MAX_PAYLOAD_CHARS) {
    throw new Error(`Payload too large (${payload.length} chars). Maximum is ${cfg.MAX_PAYLOAD_CHARS}.`);
  }

  // ── Primary model call ─────────────────────────────────────────────
  const primary  = cfg.GEMINI_MODEL          || 'gemini-1.5-flash';
  const fallback = cfg.GEMINI_MODEL_FALLBACK || 'gemini-1.5-flash-latest';

  try {
    return await _callGemini(payload, primary);
  } catch(err) {
    // Auto-retry with fallback model on quota/rate errors
    if (err.isQuota || err.isQuotaZero) {
      try {
        return await _callGemini(payload, fallback);
      } catch(err2) {
        // Both models failed — propagate original descriptive error
        throw err;
      }
    }
    throw err;
  }
}

// ─── EXPORTS ──────────────────────────────────────────────────────────────────

window.OmniDecoder = {
  inspectZeroWidth,
  analyzeBase64Padding,
  analyzeCustomAlphabet,
  inspectEntropy,
  runPipeline,
  xorBruteForce,
  caesarBruteForce,
  detectInterleavedNoise,
  detectFingerprints,
  autoAnalyze,
  analyzeWithGemini,
  textToBytes,
  hexToBytes,
  base64ToBytes,
  KNOWN_ALPHABETS,
  ZW_MAP,
};

